
#ifndef INFOPERSON_H
#define INFOPERSON_H

class InfoPerson {
public:
   std::string name;
 std::string age;
 int weight;
private:
 
};

#endif /* INFOPERSON_H */

