

#include "InfoPerson.h"
#ifndef CONTINUE_H
#define CONTINUE_H 

class Continue
{
public:
    void Info()
    {
        
    }
};




#endif /* CONTINUE_H */

