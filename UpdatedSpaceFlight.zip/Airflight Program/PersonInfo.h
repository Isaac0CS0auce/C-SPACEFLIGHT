#include <string>
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;

class PersonInfo
{
    protected:
        string lastName;
        string firstName;
        string address;
        string City;
        string State;
        string Zipcode;
        string PhoneNumber;
    
     public:
        PersonInfo(){
 }   
     
        PersonInfo(string firstName, string lastName, string address, string city,
                   string state, string zipCode, string phoneNumber){
            this -> firstName = firstName;
            this -> lastName = lastName;
            this -> City = city;
            this -> State = state;
            this -> Zipcode = zipCode;
            this -> PhoneNumber = phoneNumber;
        }
        PersonInfo(const PersonInfo &dot){
            this->lastName = dot.lastName;
            this->firstName = dot.firstName;
            this->City = dot.City;
            this->State = dot.State;
            this->Zipcode = dot.Zipcode;
            this->PhoneNumber = dot.PhoneNumber;
        }
        void SN(){
            cout <<"Enter First and Last name: ";
            cin >>firstName >> lastName; 
        }
        void SA(){
            
            cout << "Enter City: ";
            cin >> City;
            cout <<"Enter  State: ";
            cin >> State;
            cout << "Enter Zip Code: ";
            cin >> Zipcode;
        }
        void SPN(){
            cout << "Enter Phone Number: ";
            cin >> PhoneNumber;
        }
         string gN(){
            return firstName + lastName;
        }
         string gC(){
            return City;
        }
          string gS(){
            return State;
        }
        string gZ(){
            return Zipcode;
        }
        string gPN(){
            return PhoneNumber;
        }
       
};
