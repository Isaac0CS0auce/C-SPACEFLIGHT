#include "PersonInfo.h"

class PilotInfo : public PersonInfo
{
   private:
   int customerNumber;
 
  
   public:
   PilotInfo(){ 
       int customerNumber = 0;
       
   }
  
   void setNumber(){
       cout << "Enter  number: ";
       cin >> customerNumber;
   }
   int getNumber(){
       return customerNumber;
   }
  
   
  
 
};
