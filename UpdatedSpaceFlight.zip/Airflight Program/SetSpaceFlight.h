
#ifndef SETSPACEFLIGHT_H
#define SETSPACEFLIGHT_H
using namespace std;

class SetPlanet {
public:
    int choice;
    void Choice() {
       
            cout << "You have selected the moon...Flight time 3 days" << endl;
    }
        
         void Choice2()
         {
             cout << "You have selected Mars...Flight time 300 days " << endl;
         }
       
         void Choice3()
         {
             cout << "You have selected Jupiter...Flight time is 6 years " << endl;
         }
         void choice4()
         {
              cout << "You have selected Saturn...Flight time is 3 years and 2 months" << endl;
         }
         void choice5()
         {
             cout << "You have selected Uranus...Flight time is 9 1/2 years " << endl;
             
         }
         void choice6()
         {
               cout << "You have selected Neptune...Flight time is 12 years " << endl;
         }
         
    



private:
    int moon;
    int Mars;
    int Jupiter;
    int Saturn;
    int Uranus;
    int Neptune;


};








#endif /* SETSPACEFLIGHT_H */

