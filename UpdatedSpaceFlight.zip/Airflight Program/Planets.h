
#ifndef PLANETS_H
#define PLANETS_H

#include <iostream>
#include <fstream>

using namespace std;

class Planets 
 {
public:
    planets();

    void moon() {
        string line_;
        ifstream fileM("Moon.txt");
        if (fileM.is_open()) {
            while (getline(fileM, line_)) {
                cout << line_ << "\n";
            }
            fileM.close();
        }


    }

    void Mars() {
        string line_;
        ifstream fileM("Mars.txt");
        if (fileM.is_open()) {
            while (getline(fileM, line_)) {
                cout << line_ << "\n";
            }
            fileM.close();

        }
    }

    void Jupiter() {

        string line_;
        ifstream fileM("Jupiter.txt");
        if (fileM.is_open()) {
            while (getline(fileM, line_)) {
                cout << line_ << "\n";
            }
            fileM.close();

        }
    }

    void Saturn() {
        string line_;
        ifstream fileM("Saturn.txt");
        if (fileM.is_open()) {
            while (getline(fileM, line_)) {
                cout << line_ << "\n";
            }
            fileM.close();

        }
    }

    void Uranus() {
        string line_;
        ifstream fileM("Uranus.txt");
        if (fileM.is_open()) {
            while (getline(fileM, line_)) {
                cout << line_ << "\n";
            }
            fileM.close();

        }
    }

    void Neptune() {
        string line_;
        ifstream fileM("Neptune.txt");
        if (fileM.is_open()) {
            while (getline(fileM, line_)) {
                cout << line_ << "\n";
            }
            fileM.close();

        }
    }

    void Pluto() {
        string line_;
        ifstream fileM("Pluto.txt");
        if (fileM.is_open()) {
            while (getline(fileM, line_)) {
                cout << line_ << "\n";
            }
            fileM.close();

        }
    }
};



#endif /* PLANETS_H */

