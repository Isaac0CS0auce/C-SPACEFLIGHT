#include <string>
#include <iostream>
#include <iomanip>
#include <cstdlib>
using namespace std;

class PersonInfo
{//string protected variables
    protected:
        string lastName;
        string firstName;
        string address;
        string City;
        string State;
        string Zipcode;
        string PhoneNumber;
    
     public:
        PersonInfo(){
 }   //Set PersonInfo to all using this-> 
     //Over define variables for all strings
        PersonInfo(string firstName, string lastName, string address, string city,
                   string state, string zipCode, string phoneNumber){
            this -> firstName = firstName;
            this -> lastName = lastName;
            this -> address = address;
            this -> City = city;
            this -> State = state;
            this -> Zipcode = zipCode;
            this -> PhoneNumber = phoneNumber;
        }
        PersonInfo(const PersonInfo &dot){
            this->lastName = dot.lastName;
            this->firstName = dot.firstName;
            this->address = dot.address;
            this->City = dot.City;
            this->State = dot.State;
            this->Zipcode = dot.Zipcode;
            this->PhoneNumber = dot.PhoneNumber;
        }// SN = SETNAME
        void SN(){
            cout <<"Enter First and Last name: ";
            cin >>firstName >> lastName; 
        }//SA = SETADDRESS
        void SA(){
            cout <<"Enter Address: ";
            cin.ignore();
            getline(cin, address);
            cout << "Enter City: ";
            cin >> City;
            cout <<"Enter  State: ";
            cin >> State;
            cout << "Enter Zip Code: ";
            cin >> Zipcode;
        }//SPN = SETPHONENUMBER
        void SPN(){
            cout << "Enter Phone Number: ";
            cin >> PhoneNumber;
        }//gN = getName
         string gN(){
            return firstName + lastName;
        }//gA = getAddress
        string gA(){
            return address;
        }//gC = getCity
         string gC(){
            return City;
        }//gS = getState
          string gS(){
            return State;
        }//gZ = getZip
        string gZ(){
            return Zipcode;
        }//gPN = getPhoneNumber
        string gPN(){
            return PhoneNumber;
        }
       
};
