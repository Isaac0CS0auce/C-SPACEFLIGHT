#include "PersonInfo.h"

class PilotInfo : public PersonInfo
{
   private:
   int customerNumber;
   bool mailingList;
  
   public:
   PilotInfo(){ 
       int customerNumber = 0;
       bool mailingList = false;
   }
   PilotInfo(int customerNumber, bool mailingList){
       this -> customerNumber = customerNumber;
       this -> mailingList = mailingList;
   }
   void setNumber(){
       cout << "Enter  number: ";
       cin >> customerNumber;
   }
   int getNumber(){
       return customerNumber;
   }
   void setMail(){
       cout << "Do you wanna be part of the mailing list: ";
      cin >> mailingList;
   }
   bool getMail(){
    return mailingList;   
   }
};
