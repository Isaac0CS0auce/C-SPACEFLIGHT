
/* Author: Isaac Anthony Hernandez
 *
 * Created on May 16, 2019, 1:44 AM
 */
//SpaceFlight Program Final Project
#include <iostream>
#include <string>
#include "PilotInfo.h" 
#include <fstream>
#include "Planets.h"
using namespace std;

int main() {
    Planets p;
    string name;
    string age;
    int choice;
    int choice1;
    int R;
    void menu();
    void moon();
    void Mars();
    void Jupiter();
    void Saturn();
    void Uranus();
    void Neptune();
    void Pluto();
    void menu2();

    menu();
    cin >> choice;
    if (choice != '1' || choice != '2' || choice != '3' || choice != '4' || choice != '5' || choice != '6')
    {   cout << "Please enter the correct choice of your destination:"<<  endl;
    cin >> choice;
    }
                     
        
       
    do {  menu2();
    cin >> choice;  
   
        switch (choice) {
            case 1:
                p.moon();
                cout << " You have chosen Moon. Would you like to choose this destination?" << endl;
                cout << "       YES[1]                  NO[2]" << endl;
                cout << " Flight time in Space: 3 days " << endl;

                cin >> R;
                break;
            case 2:
                p.Mars();

                cout << " You have chosen Mars. Would you like to choose this destination?" << endl;
                cout << "       YES[1]                  NO[2]" << endl;
                cout << " Flight Time in Space: 300 days " << endl;

                cin >> R;
                break;

            case 3:

                p.Jupiter();

                cout << " You have chosen Jupiter. Would you like to choose this destination?" << endl;
                cout << "       YES[1]                  NO[2]" << endl;
                cout << " Flight time in Space: 6 years " << endl;

                cin >> R;
                break;
            case 4:
                p.Saturn();

                cout << " You have chosen Saturn. Would you like to choose this destination?" << endl;
                cout << "       YES[1]                  NO[2]" << endl;
                cout << " Flight time in Space: 3 years and 2 months" << endl;
                cin >> R;
                break;
            case 5:
                p.Uranus();

                cout << " You have chosen Uranus. Would you like to choose this destination?" << endl;
                cout << "       YES[1]                  NO[2]" << endl;
                cout << " Flight time in Space: 9, 1/2 years " << endl;
                cin >> R;
                break;
            case 6:
                p.Neptune();

                cout << " You have Chosen Neptune. Would you like to choose this destination?" << endl;
                cout << "       YES[1]                  NO[2]" << endl;
                cout << "Flight time in Space: 12 years " << endl;
                cin >> R;
                break;
            default:
                cout << "Please select [1]Yes or [2] No";

        }
    } while (R != 1);
    
    if (R == 1) {
    PilotInfo person;
        
    person.SN();    
    person.SA();
    person.SPN();


    
            cout <<endl;
            cout <<"Passenger's name: "<< person.gN()<<endl;
            cout <<"Passenger's address: "<< person.gA()<<endl;
            cout <<"Passenger's city: "<< person.gC()<<endl;
            cout <<"Passenger's state: "<< person.gS()<<endl;
            cout <<"Passenger's zip: "<< person.gZ()<<endl;
            cout <<"Passenger's phone number: "<< person.gPN()<<endl;
    }
    return 0;

}


//created a menu for the user to select which flight to choose

void menu() {
    cout << "                                                              " << endl;
    cout << "                   WELCOME TO SPACEFLIGHT                    " << endl;
    cout << "===========================================================" << endl;
    cout << "===========================================================" << endl;
    cout << "()()()()()()()()()()()lIST OF FLIGHTS()()()()()()()()()()()" << endl;
    cout << "    Please select the destination of your choice" << endl;
    cout << "                  (Area MilkyWay) Moon    [1] " << endl;
    cout << "                  (Area MilkyWay) Mars    [2] " << endl;
    cout << "                  (Area MilkyWay) Jupiter [3] " << endl;
    cout << "                  (Area MilkyWay) Saturn  [4] " << endl;
    cout << "                  (Area MilkyWay) Uranus  [5] " << endl;
    cout << "                  (Area MilkyWay) Neptune [6] " << endl;


}
void menu2()
{
    cout << "                  (Area MilkyWay) Moon    [1] " << endl;
    cout << "                  (Area MilkyWay) Mars    [2] " << endl;
    cout << "                  (Area MilkyWay) Jupiter [3] " << endl;
    cout << "                  (Area MilkyWay) Saturn  [4] " << endl;
    cout << "                  (Area MilkyWay) Uranus  [5] " << endl;
    cout << "                  (Area MilkyWay) Neptune [6] " << endl;

}

//print the choices the user selects followed by the switch statement 




